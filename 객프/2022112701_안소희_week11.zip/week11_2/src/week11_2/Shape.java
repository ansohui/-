package week11_2;

public class Shape {
	private static int iCnt=0;//0~9의 증가하는 숫자를 얻기 위해 static으로 선언 
	private int iNum;//위의 값을 객체마다 저장해주기 위해 선언 
	Shape(){
		iNum = iCnt;//인덱스값 저장 
		iCnt++;//증가 
	}
	public void draw() {//push할 때 사용 
		System.out.println("Shape"+iNum+" is allocated");
	}
	public int getiNum() {
		return iNum;//pop에서 어떤 순서로 pop하는 지 알기 위해 사용한다.
	}
}
