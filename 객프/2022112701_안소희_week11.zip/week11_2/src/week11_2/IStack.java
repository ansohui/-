package week11_2;

public interface IStack<T> {//인터페이스로 정의하여 상속받은 클래스가 구현하도록 한다 
	T pop();
	boolean push(T ob);
}
