package week11_2;

public class StackEx {
    public static void main(String[] args) {
        
        MyStack<Shape> shapeStack = new MyStack<Shape>();//Shape라는 타입을 정하고 MyStack 인스턴스 생성
        int iPopNum;

        for (int i = 0; i < 10; i++) {
        	Shape newShape = new Shape();//Shape 인스턴스 생성 
            newShape.draw(); //draw호출하여 할당문구 출력 
            shapeStack.push(newShape);//Stack에 push한다. 
        }

        // Shape 객체를 순서대로 pop 
        while (!shapeStack.isEmpty()) {//비어있으면 pop하지 않도록 
            Shape poppedShape = shapeStack.pop();
            if (poppedShape != null) {
            	iPopNum = poppedShape.getiNum();//각 객체가 지닌 수를 getiNum으로 얻어냄 
                System.out.print(iPopNum+"  ");//그 수를 출력한다. 
            }
        }
    }
}
