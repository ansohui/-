package week11_2;
import java.util.Vector;
class MyStack<T> implements IStack<T> {
    private Vector<T> stack;

    public MyStack() {
        stack = new Vector<T>();//Vector를 이용해 stack생성 
    }

    @Override
    public T pop() {//IStack<T>오버라이드 
        if (isEmpty()) {//비어있으면 
            return null; // 스택이 비어있을 때 pop 시도 시 null 반환
        } else {
            int lastIndex = stack.size() - 1;//0부터 시작이므로 크기-1를 마지막 인덱스로 둔다 
            T element = stack.get(lastIndex);//마지막 인덱스에 해당하는 요소를 Vector의 get함수를 이용해 얻는다 
            stack.remove(lastIndex);//Vector에서 값을 삭제하는 함수인 remove를 사용하여 마지막 요소를 지운다.
            return element;//요소를 반환 
        }
    }

    @Override
    public boolean push(T obpush) {
        return stack.add(obpush);//Vector의 값을 추가하는 함수인 add를 통해 push 
    }

    public boolean isEmpty() {
        return stack.isEmpty();//스택이 비었는지 확인한다. 
    }
}

