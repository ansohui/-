package week11_1;

import java.util.StringTokenizer;

import java.util.Scanner;

public class StringModification {

	public static void main(String[] args) {
        // 사용자로부터 원본 문자열 입력
		Scanner scanner = new Scanner(System.in);
		System.out.print("원본 문자열을 입력하세요: ");
        String inputString = scanner.nextLine();
        
		while(true) {
	
	        // 사용자로부터 수정 명령 문자열 입력
	        System.out.print("명령: ");
	        String command = scanner.nextLine();
	        if(command.equals("그만")) {//그만 입력 시 종료 
	        	System.out.println("종료합니다.");
	        	break;
	        }
	        if (command.startsWith("!")) {//만약 수정 문자열이 없을 경우 에러메세지 출력 
                System.out.println("잘못된 명령입니다.");
            
            }
	        else {
		        // 문자열을 수정하는 메소드 호출
		        String modifiedString = modifyString(inputString, command);
		
		        // 수정된 결과 출력
		        System.out.println("Modified String: " + modifiedString);
		        inputString = modifiedString;//수정된 문자열로 inputString재할당 
	        }
	        
		}
        
        scanner.close();
    }

    // 문자열을 수정하는 메소드
    private static String modifyString(String inputString, String command) {
        // StringBuffer를 사용하여 문자열을 수정
        StringBuffer bInputString = new StringBuffer(inputString);

        // StringTokenizer를 사용하여 문자열을 분리
        StringTokenizer tokenizerString = new StringTokenizer(command, "!");

        //수정할 문자열 찾음
        String findToken = tokenizerString.nextToken();

        // 원본 문자열에서 첫 번째 만난 문자열을 수정(!전 문자열)
        int index = bInputString.indexOf(findToken);//수정할 단어 찾아 인덱스 반환
        if (index != -1) {//인덱스가 -1 아닐 때(존재 할 때)
            // 수정 실행 
            bInputString.replace(index, index + findToken.length(), "");//빈 문자열로 바꿈
            bInputString.insert(index, tokenizerString.nextToken());//수정할 문자열로 변경
            
        } else {
            System.out.println("찾을 수 없습니다! ");//인덱스가 -1일 때
        }
        
        
        // 수정된 문자열 반환
        return bInputString.toString();
    }
}