package week12_1;
import java.util.LinkedList;
import java.util.Scanner;

public class StudentEx {
    private static LinkedList<Student> studentList = new LinkedList<Student>();//LinkedList로 학생들의 정보를 저장 
    private static Scanner oInDev = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. 전체 학생의 학점 평균 조회");
            System.out.println("2. 학생 정보 등록");
            System.out.println("3. 학생 정보 삭제");
            System.out.println("4. 종료");
            System.out.print("선택: ");

            int choice = oInDev.nextInt();
            oInDev.nextLine(); // 개행 문자 처리

            switch (choice) {
                case 1:
                	displayStudentAverage();//학생의 평균 학점 조회 
                    break;
                case 2:
                    registerStudent();//학생 정보 등록 
                    break;
                case 3:
                    deleteStudent();//학생 정보 삭제 
                    break;
                case 4:
                    System.out.println("프로그램을 종료합니다.");
                    oInDev.close();
                    System.exit(0);
                default:
                    System.out.println("올바른 선택이 아닙니다. 다시 선택해주세요.");
            }
        }
    }

    private static void displayStudentAverage() {
        if (studentList.isEmpty()) {
            System.out.println("등록된 학생 정보가 없습니다.");//List가 비어있으면 에러 메세지 출력 
            return;
        }

        System.out.print("조회할 학생의 이름을 입력하세요: ");
        String studentName = oInDev.nextLine();

        boolean found = false;
        for (int i = 0; i < studentList.size(); i++) {
            Student student = studentList.get(i);//i는 해당 리스트의 인덱스를 나타냄 

            if (student.name.equals(studentName)) {//만약 입력한 이름이 List에 존재한다면 
                System.out.println(student.name + "의 학점 평균: " + student.averageGrade);
                found = true;
                break;
            }
        }

        if (!found) {//만약 입력한 이름이 List에 존재하지 않다면 
            System.out.println("입력한 이름의 학생이 등록되어 있지 않습니다.");
        }
    }

    private static void registerStudent() {
        System.out.print("학생 이름: ");
        String name = oInDev.nextLine();

        System.out.print("학과: ");
        String department = oInDev.nextLine();

        System.out.print("학점 평균: ");
        double averageGrade = oInDev.nextDouble();
        oInDev.nextLine(); // 개행 문자 처리

        Student newStudent = new Student(name, department, averageGrade);//이름과 학과, 평균 학점을 매개변수로 하는 Student객체 생
        studentList.add(newStudent);//List에 새로 생성한 Student객체 추가 

        System.out.println("학생 정보가 등록되었습니다.");
    }
    
    private static void deleteStudent() {
        if (studentList.isEmpty()) {//리스트에 요소가 없을 때 에러메세지 출력 
            System.out.println("등록된 학생 정보가 없습니다.");
            return;
        }

        System.out.print("삭제할 학생의 이름을 입력하세요: ");
        String sDeleteName = oInDev.nextLine();

        boolean found = false;
        int listSize = studentList.size();
        for (int i = 0; i < listSize; i++) {
            Student student = studentList.get(i);//리스트의 해당 인덱스 위치에 있는 Student객체 
            
            if (student.name.equals(sDeleteName)) {
                studentList.remove(i);//만약 위에서 구한 Student객체의 이름과 사용자가 입력한 이름이 같다면 
                found = true;//found를 true로 바꾼다.
                System.out.println("학생 정보가 삭제되었습니다.");
                break;
            }
        }


        if (!found) {//찾지 못했다면 
            System.out.println("입력한 이름의 학생이 등록되어 있지 않습니다.");
        }
    }
}