package week12_2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Scanner;

public class CustomerEx {

    public static void main(String[] args) {
        // HashMap을 사용하여 고객의 이름과 포인트를 저장
        HashMap<String, Integer> customerPoints = new HashMap<String, Integer>();
        int iMenu;
        String sName = null;
        int iPoint;
        Scanner oInDev  = new Scanner(System.in);
        // 고객 정보 추가
        while(true) {
        	
        	System.out.println("1. 특정 고객 포인트 저장 \n2. 고객 정보 검색 \n3. 모든 고객 정보 출력 \n4. 종료");
        	iMenu = oInDev.nextInt();
        	
        	if(iMenu == 4) {//종료 
        		System.out.println("종료합니다");
        		break;
        	}
        	else if(iMenu == 1) {//포인트 적립 
        		System.out.println("이름 입력 ");
        		sName = oInDev.next();
        		
        		System.out.println("포인트 입력 ");
        		iPoint = oInDev.nextInt();
        		
        		managePoints(customerPoints,sName, iPoint);
        	}
        	else if(iMenu == 2) {//고객 정보 검색 
        		System.out.println("이름 입력 ");
        		sName = oInDev.next();
        		
        		// 고객 정보 검색
                searchCustomer(customerPoints, sName);
        	}
        	else if(iMenu == 3) {// Iterator를 사용하여 모든 고객 정보 출력
        		
                printAllCustomer(customerPoints);
        	}
        	
        }
        oInDev.close();
   
        

        
    }

    // 포인트를 추가하고 누적하여 저장하는 메서드
    private static void managePoints(HashMap<String, Integer> customerPoints, String customerName, int points) {
        if (customerPoints.containsKey(customerName)) {
            // 이미 존재하는 고객의 경우 포인트를 누적하여 업데이트
            int iCurrentPoints;
            iCurrentPoints= customerPoints.get(customerName) + points;//해시맵에서 key인 customerName으로 포인트를 얻어 추가할 포인트를 더해 최신 포인트에 저장해준다.
            
            customerPoints.put(customerName, iCurrentPoints);//최신 포인트와 고객이름을 업데이트  
            
        } else {
            // 새로운 고객인 경우 새로운 항목으로 추가
            customerPoints.put(customerName, points);
        }
    }

    // 특정 고객의 포인트 정보를 검색하는 메서드
    private static void searchCustomer(HashMap<String, Integer> customerPoints, String customerName) {
        if (customerPoints.containsKey(customerName)) {//key에 고객 이름이 존재하면 
            System.out.println(customerName + "의 포인트: " + customerPoints.get(customerName));//포인트 정보 출
        } else {
            System.out.println(customerName + "은 존재하지 않습니다.");
        }
    }

    // Iterator를 사용하여 모든 고객의 포인트 정보 출력
    private static void printAllCustomer(HashMap<String, Integer> customerPoints) {
        System.out.println("전체 고객 포인트 정보:");
        Iterator<Map.Entry<String, Integer>> iterator = customerPoints.entrySet().iterator();

        while (iterator.hasNext()) {//다음 요소가 존재한다면 
            Map.Entry<String, Integer> entry = iterator.next();//key-value쌍을 받아옴 
            System.out.println(entry.getKey() + ": " + entry.getValue() + " 포인트");//Map.Entry메서드를 이용하여 정보 출력 
        }
    }
}

