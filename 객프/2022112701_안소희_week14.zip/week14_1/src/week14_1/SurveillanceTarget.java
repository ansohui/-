package week14_1;

public abstract class SurveillanceTarget {
	private int x, y;
	
	public SurveillanceTarget() {//기본 생성자 
		
	}
	public SurveillanceTarget(int iX, int iY) {//x와 y를 인자로 받는 생성자 
			this.x = iX;
			this.y = iY;
	}
	public void setX (int iX) {//x설정
		x = iX;
	}
	public int getX() {//x반환 
		return x;
	}
	public void setY (int iY) {//y설정
		y = iY;
	}
	public int getY( ) {//y반환 
		return y;
	}
	public abstract void printInfo();//추상 메소드 : 정보 출력 메소드 
	
	public String toString() {
		return "("+x+","+y+")";
	}
	
}
