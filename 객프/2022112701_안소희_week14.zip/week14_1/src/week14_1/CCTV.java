package week14_1;
//시뮬레이션에서 사용되는 CCTV 객체 클래스
public class CCTV { 
	private int x, y, visibleDist; //위치와 탐지 거리 
	public CCTV () {}
	public CCTV (int iX, int iY, int iVisibleDist) {
		x = iX;
		y = iY;
		visibleDist = iVisibleDist;
	}
	public void setX (int iX) {
		x = iX;
	}
	public int getX() {
		return x;
	}
	public void setY (int iY) {
		y = iY;
	}
	public int getY( ) {
		return y;
	}
	public void setVisibleDist (int iVisibleDist) {
		visibleDist = iVisibleDist;
	}
	public int getVisibleDist() {
		return visibleDist;
	}
}