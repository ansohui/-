package week14_1;
//시뮬레이션에서 사용되는 사람 객체 클래스
public class Person extends SurveillanceTarget implements Movable {
    private int speed;  // 사람의 속도
    
    public Person(int x, int y, int speed) {
        super(x, y);
        this.speed = speed;
    }

   
	@Override
	public void printInfo() {
		
		 System.out.println("Person - Position: (" + getX() + ", " + getY() + "), Speed: " + speed);
	}

	@Override
	public void move(int iDestX, int iDestY) {//목표 위치로 이동 
		
		setX(iDestX);
        setY(iDestY);
		
	}
}
