package week14_1;

public class Building extends SurveillanceTarget {
    private int height;  // 건물의 높이
    public Building() {//기본 생성자 
        
    }
    public Building(int x, int y, int height) {//위치와 높이 지정 생성자 
        super(x, y);
        this.height = height;
    }

	@Override
	public void printInfo() {//정보 출력 메소드 
		
		System.out.println("Building - Position: (" + getX() + ", " + getY() + "), Height: " + height);
	}
}