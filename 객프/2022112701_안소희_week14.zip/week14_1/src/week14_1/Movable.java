package week14_1;

public interface Movable {//목표 위치로 이동 메소드 
	abstract void move(int iDestX, int iDestY);
}
