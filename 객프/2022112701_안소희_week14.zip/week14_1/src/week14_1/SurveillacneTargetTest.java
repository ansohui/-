package week14_1;

import java.util.Scanner; 
import java.util.Arrays; 
public class SurveillacneTargetTest { 
	//빌딩 정보 입력 후 맵에 표시 
	 public static void setBuildingsInfo(Scanner oInDev, int iBuildingsNum, Building[] oBuildings, char[][] oWorld) {
	        for (int i = 0; i < iBuildingsNum; i++) {
	            System.out.print((i + 1) + "번째 건물 정보를 입력하세요 (x y height): ");
	            int x = oInDev.nextInt();
	            int y = oInDev.nextInt();
	            int height = oInDev.nextInt();
	            oBuildings[i] = new Building(x, y, height);
	            oWorld[y][x] = 'b';
	        }
	    }
	//사람 정보 입력 후 맵에 표시 
	 public static void setPeopleInfo(Scanner oInDev, int iPeopleNum, Person[] oPeople, char[][] oWorld) {
	        for (int i = 0; i < iPeopleNum; i++) {
	            System.out.print((i + 1) + "번째 사람 정보를 입력하세요 (x y speed): ");
	            int x = oInDev.nextInt();
	            int y = oInDev.nextInt();
	            int speed = oInDev.nextInt();
	            oPeople[i] = new Person(x, y, speed);
	            oWorld[y][x] = 'p';
	        }
	    }
	//CCTV 정보 입력 후 맵에 표시 
	 public static void setCCTVsInfo(Scanner oInDev, int iCCTVNum, CCTV[] occtvs, char[][] oWorld) {
	        for (int i = 0; i < iCCTVNum; i++) {
	            System.out.print((i + 1) + "번째 CCTV 정보를 입력하세요 (x y visibleDist): ");
	            int x = oInDev.nextInt();
	            int y = oInDev.nextInt();
	            int visibleDist = oInDev.nextInt();
	            occtvs[i] = new CCTV(x, y, visibleDist);
	            oWorld[y][x] = 'c';
	        }
	    }
	 //맵 출력 
	 public static void printWorld(char[][] cWorld, int iMaxPos) {
	        for (int i = 0; i < iMaxPos; i++) {
	            for (int j = 0; j < iMaxPos; j++) {
	                System.out.print(cWorld[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }
	public static void main (String[] args) {
		int buildingsNum; 
		int peopleNum; 
		int ccvtNum; 
		Building[] buildings; 
		Person [] people; 
		CCTV [ ] cctvs; 
		int maxPos = 10; 
		char [ ] [] world = new char [maxPos] [maxPos]; 
		//아무것도 없으면 '-' 
		for (int i = 0; i < maxPos; ++i) {
			Arrays.fill(world[i], '-'); 
		} 
		Scanner oInDev = new Scanner (System. in); 
		System. out.print ("건물 수를 입력하시오: "); 
		buildingsNum = oInDev.nextInt(); 
		buildings = new Building [buildingsNum]; 
		System. out.print ("사람 수를 입력하시오: "); 
		peopleNum = oInDev.nextInt () ; 
		people = new Person[peopleNum]; 
		System. out.print ("CCTV 수를 입력하시오: "); 
		ccvtNum = oInDev.nextInt (); 
		cctvs = new CCTV[ccvtNum]; 
		//입력받은 수를 기반으로 맵에 표시하기 위해 world배열에 저장 
		setBuildingsInfo(oInDev, buildingsNum, buildings, world);
		System. out.println(); 
		setPeopleInfo(oInDev, peopleNum, people, world); 
		System. out.println(); 
		setCCTVsInfo(oInDev, ccvtNum, cctvs, world); 
		System.out.println(); 
		
		//맵 출력 
		printWorld(world, maxPos);
	}
	
}
