package week14_2;

public interface Movable {
	abstract void move(int iDestX, int iDestY);
}
