package week14_2;

import java.util.Scanner; 


import java.util.Arrays; 
public class SurveillacneTargetTest { 
//빌딩 정보 입력 후 맵에 표시 
	 public static void setBuildingsInfo(Scanner oInDev, int iBuildingsNum, Building[] oBuildings, char[][] oWorld) {
	        for (int i = 0; i < iBuildingsNum; i++) {
	            System.out.print((i + 1) + "번째 건물 정보를 입력하세요 (x y height): ");
	            int x = oInDev.nextInt();
	            int y = oInDev.nextInt();
	            int height = oInDev.nextInt();
	            oBuildings[i] = new Building(x, y, height);
	            oWorld[y][x] = 'b';
	        }
	    }
	//사람 정보 입력 후 맵에 표시 
	 public static void setPeopleInfo(Scanner oInDev, int iPeopleNum, Person[] oPeople, char[][] oWorld) {
	        for (int i = 0; i < iPeopleNum; i++) {
	            System.out.print((i + 1) + "번째 사람 정보를 입력하세요 (x y speed): ");
	            int x = oInDev.nextInt();
	            int y = oInDev.nextInt();
	            int speed = oInDev.nextInt();
	            oPeople[i] = new Person(x, y, speed);
	            oWorld[y][x] = 'p';
	        }
	    }
	//CCTV 정보 입력 후 맵에 표시 
	 public static void setCCTVsInfo(Scanner oInDev, int iCCTVNum, CCTV[] occtvs, char[][] oWorld) {
	        for (int i = 0; i < iCCTVNum; i++) {
	            System.out.print((i + 1) + "번째 CCTV 정보를 입력하세요 (x y visibleDist): ");
	            int x = oInDev.nextInt();
	            int y = oInDev.nextInt();
	            int visibleDist = oInDev.nextInt();
	            occtvs[i] = new CCTV(x, y, visibleDist);
	            oWorld[y][x] = 'c';
	        }
	    }
	 //맵 출력 
	 public static void printWorld(char[][] cWorld, int iMaxPos) {
	        for (int i = 0; i < iMaxPos; i++) {
	            for (int j = 0; j < iMaxPos; j++) {
	                System.out.print(cWorld[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }
	public static void main (String[] args) {
		int buildingsNum; 
		int peopleNum; 
		int ccvtNum; 
		int destX;
		int destY;
		Building[] buildings; 
		Person [] people; 
		CCTV [ ] cctvs; 
		int maxPos = 10; 
		char [ ] [] world = new char [maxPos] [maxPos]; 
		for (int i = 0; i < maxPos; ++i) {
			Arrays.fill(world[i], '-'); 
		} 
		Scanner oInDev = new Scanner (System. in); 
		System. out.print ("건물 수를 입력하시오: "); 
		buildingsNum = oInDev.nextInt(); 
		buildings = new Building [buildingsNum]; 
		System. out.print ("사람 수를 입력하시오: "); 
		peopleNum = oInDev.nextInt () ; 
		people = new Person[peopleNum]; 
		System. out.print ("CCTV 수를 입력하시오: "); 
		ccvtNum = oInDev.nextInt (); 
		cctvs = new CCTV[ccvtNum]; 
		//받은 각각의 수로 정보를 저장하기 위해 메소드 호출
		setBuildingsInfo(oInDev, buildingsNum, buildings, world); 
		System. out.println(); 
		setPeopleInfo(oInDev, peopleNum, people, world); 
		System. out.println(); 
		setCCTVsInfo(oInDev, ccvtNum, cctvs, world); 
		System.out.println(); printWorld(world, maxPos);
		
		// 5번의 이동을 시뮬레이션
		for (int moveCount = 1; moveCount <= 5; moveCount++) {
		    System.out.println("이동 " + moveCount + "회:");
		    for (Person person : people) {
            	int x = person.getX();
            	int y = person.getY();

            	int speed = person.getSpeed();
            	
            	int iFlag;
            	while (true) {
            		
            		iFlag =  (int)(Math.random()*4);//랜덤 양수 음수 설정 
            		int iXRand = (int)(Math.random()*speed);//X변화량
	            	int iYRand = speed - iXRand;//Y변화량 
	                
            	    
	            	//랜덤으로 iFlag정해서 움직일 방향 정하기 
            		if(iFlag == 0) {
            		   	destX = x + iXRand;
            		   	destY = y + iYRand;
            		   
            		}
            		else if(iFlag == 1){
            			destX = x + iXRand;
   	                	destY = y - iYRand;
   	                	
   	                	
            		}
            		else if(iFlag == 2) {
            			 destX = x + iXRand;
            			 destY = y + iYRand;
            		}
            		else {
               			destX = x - iXRand;
      	                destY = y - iYRand;
            		}
      	                	
               		   
            	   //배열 내에 있으면 멈춘다 
            	   if(destX < maxPos&&destY < maxPos&&destX>=0&&destY>=0) {
            		   break;
            	   }
            	   
            	   
            	}
                world[y][x] = '-';
                // 감시 대상의 위치 업데이트
                if(world[destY][destX] != '-') {
                	System.out.println(world[destY][destX]+"와 충돌하여 원위치로 돌아갔습니다.");
                	destY = y;
                	destX = x;
                }
                world[destY][destX] = 'p';
                person.move(destX, destY);
		        // 각 CCTV와의 탐지 여부 확인
                //감지된 사람 정보 출력 
		        for (CCTV cctv : cctvs) {
		            int manhattanDistance = (Math.abs(x) - cctv.getX()) + Math.abs(y - cctv.getY());
		            if (manhattanDistance <= cctv.getVisibleDist()) {
		                System.out.println("CCTV(" + cctv.getX() + ", " + cctv.getY() + ")에 의해 사람 발견");
		                
		                person.printInfo();
		            }
		        }
		    }

//		    // 감지된 빌딩 정보 출력
		    for (Building building : buildings) {
		    for (int i = 0; i < cctvs.length; i++) {
		        CCTV cctv = cctvs[i];
				int manhattanDistance = Math.abs(building.getX() - cctv.getX()) + Math.abs(building.getY() - cctv.getY());
		        if (manhattanDistance <= cctv.getVisibleDist()) {
		            System.out.println("CCTV(" + cctv.getX() + ", " + cctv.getY() + ")에 의해 건물 발견");
		            building.printInfo();
		        }
		    }
			}


		    // 각 이동 후의 세계 지도 출력
		    printWorld(world, maxPos);
		    System.out.println();
		}

	
	}
}
	

