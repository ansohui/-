package week14_2;

public class Building extends SurveillanceTarget {
    private int height;  // 건물의 높이
    public Building() {
        
    }
    public Building(int x, int y, int height) {
        super(x, y);
        this.height = height;
    }

	@Override
	public void printInfo() {
		// TODO Auto-generated method stub
		System.out.println("Building - Position: (" + getX() + ", " + getY() + "), Height: " + height);
	}
}