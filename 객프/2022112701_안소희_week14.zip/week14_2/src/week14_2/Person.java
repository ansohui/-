package week14_2;
//시뮬레이션에서 사용되는 사람 객체 클래스
public class Person extends SurveillanceTarget implements Movable {
    private int speed;  // 사람의 속도
    
    public Person(int x, int y, int speed) {
        super(x, y);
        this.speed = speed;
    }

   public int getSpeed() {
	   return speed;
   }
	@Override
	public void printInfo() {
		
		 System.out.println("Person - Position: (" + getX() + ", " + getY() + "), Speed: " + speed);
	}
	

	@Override
	public void move(int iDestX, int iDestY) {
		 
		    // 직접 좌표를 업데이트
		    this.setX(iDestX);
		    this.setY(iDestY);    
		    
	}
}
