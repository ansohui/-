package week14_2;

public abstract class SurveillanceTarget {
	private int x, y;
	
	public SurveillanceTarget() {
		
	}
	public SurveillanceTarget(int iX, int iY) {
		 this.x = iX;
	     this.y = iY;
	}
	public void setX (int iX) {
		x = iX;
	}
	public int getX() {
		return x;
	}
	public void setY (int iY) {
		y = iY;
	}
	public int getY( ) {
		return y;
	}
	public abstract void printInfo();
	
	public String toString() {
		return "x"+"y";
	}
	
}
