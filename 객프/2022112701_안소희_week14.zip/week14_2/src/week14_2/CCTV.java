package week14_2;
//시뮬레이션에서 사용되는 CCTV 객체 클래스
public class CCTV { 
	private int x, y, visibleDist; 
	public CCTV () {}
	public CCTV (int iX, int iY, int iVisibleDist) {
		//채우기 
		x = iX;
		y = iY;
		visibleDist = iVisibleDist;
	}
	public void setX (int iX) {
		x = iX;
	}
	public int getX() {
		return x;
	}
	public void setY (int iY) {
		y = iY;
	}
	public int getY( ) {
		return y;
	}
	public void setVisibleDist (int iVisibleDist) {
		visibleDist = iVisibleDist;
	}
	public int getVisibleDist() {
		return visibleDist;
	}
}